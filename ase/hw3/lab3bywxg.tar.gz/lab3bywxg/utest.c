/**************************************************************************************************/
/* Copyright (C) xxxxxxx.com, SSE@USTC, 2014-2015                                                 */
/*                                                                                                */
/*  FILE NAME             :  test.c                                                               */
/*  PRINCIPAL AUTHOR      :  WangXianggang                                                        */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/21                                                           */
/*  DESCRIPTION           :  This is test of menu module                                          */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Wxg, 2014/09/21
 */

#include<stdio.h>
#include<stdlib.h>
#include"linktable.h"
#include"menu.h"
#define debug 

#define CMD_MAX_LEN 10
#define TEST_SIZE 12

int add1(tLinkTable *pLinkTable);
int add2(tLinkTable *pLinkTable);


typedef struct tCase
{
    tLinkTable * pLinkTable;
    char*   cmd;
    int     (*handler)();
    int     expect;
    int     result;
    char*   desc;
}tTestCase;


const char* desc[] = 
{
    "succ: add success",
    "err: head pt null",
    "err: cmd null",
    "err: already cmd exist",
    "err: the hander null"
}; 


int main()
{
    int i;
    int result = 0;
    tLinkTable * pLinkTable = CreateLinkTable();

    /* init menu whih the common item, help, version, and exit */
    InitMenuItem(pLinkTable);    


    tTestCase testAddMenuItem[] = 
    {
        {NULL,        NULL,         NULL,  1,  0,  "unInit"},          /*  */
        {NULL,        NULL,         add1,  1,  0,  "unInit"},          /*  */

        {NULL,        "version",    NULL,  1,  0,  "unInit"},          /*  */
        {NULL,        "version",    add1,  1,  0,  "unInit"},          /*  */

        {NULL,        "addNew1",    NULL,  1,  0,  "unInit"},          /*  */
        {NULL,        "addNew2",    add1,  1,  0,  "unInit"},          /*  */

        {pLinkTable,  NULL,         NULL,  2,  0,  "unInit"},          /*  */
        {pLinkTable,  NULL,         add1,  2,  0,  "unInit"},          /*  */

        {pLinkTable,  "version",    NULL,  3,  0,  "unInit"},          /*  */
        {pLinkTable,  "version",    add1,  3,  0,  "unInit"},          /*  */

        {pLinkTable,  "addNew3",    NULL,  4,  0,  "unInit"},          /*  */
        {pLinkTable,  "addNew4",    add1,  0,  0,  "unInit"},          /*  */

    };

    printf("\n***************************************************************************\n");

    printf("num   MenuHead  cmd      handler expect result desc                   isPass\n");



    for(i=0; i < TEST_SIZE; i++)
    {

        result = AddMenuItem(testAddMenuItem[i].pLinkTable, testAddMenuItem[i].cmd, "test", testAddMenuItem[i].handler);

        printf("%-6d", i+1);

        if(NULL != testAddMenuItem[i].pLinkTable)
        {
            printf("yes       ");
        }
        else
        {
            printf("null      ");
        }


        if(NULL != testAddMenuItem[i].cmd)
        {
            printf("%-9s", testAddMenuItem[i].cmd);
        }
        else
        {
            printf("null     ");
        }

        

        if(NULL != testAddMenuItem[i].handler)
        {
            printf("yes     ");
        }
        else
        {
            printf("null    ");
        }

        printf("%-7d", testAddMenuItem[i].expect);

        printf("%-7d", result);

        printf("%-23s", desc[result]);

        printf("pass\n");

        /*debug(desc[result]);*/
    }

    printf("\n***************************************************************************\n");
 


    /* Add new item to the exist menu dynamicly */
    /*
    AddMenuItem(pLinkTable, "add1", "add menu1", add1);
    AddMenuItem(pLinkTable, "add2", "add menu2", add1);
    */

    /* cmd line begins */
    /*
    while(1)
    {
        char cmd[CMD_MAX_LEN];
        printf("Input a cmd > ");
        scanf("%s", cmd);
    */
        /* call the func to run the menu 
        RunMenu(pLinkTable, cmd);
    }
    DeleteLinkTable(pLinkTable);
    */
}

/* show version information */
int add1(tLinkTable *pLinkTable)
{
    printf("add menu one\n");
    return 0; 
}

int add2(tLinkTable *pLinkTable)
{
    printf("add menu two\n");
    return 0; 
}



